from datetime import datetime
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.views import View
from django.contrib.auth.forms import UserCreationForm
from googlesearch import search
import json
# Create your views here.


def index(request):
    return render(request, "index.html")


class SignoutViews(View):
    def get(self, request):
        return render(request, "signout.html")

    def post(self, request):
        return redirect("index")


class LoginViews(View):
    def get(self, request):
        return render(request, "login.html")

    def post(self, request):

        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            fname = user.first_name
            return render(request, "search.html", {"fname": fname})

        else:
            messages.error(request, "bad credentials !!")
            return render(request, "login.html")

        return render(request, "login.html")


class SignupViews(View):
    def get(self, request):
        return render(request, "signup.html")

    def post(self, request):

        user_created = request.POST
        username = request.POST.get("username")
        fname = request.POST.get("fname")
        lname = request.POST.get("lname")
        email = request.POST.get("email")
        password = request.POST.get("password")

        my_user = User.objects.create_user(username, email, password)

        my_user.first_name = fname
        my_user.last_name = lname

        my_user.save()

        messages.success(
            request, "Your Account has been successfully created !!!! ")

        return redirect("login")
      #  return render(request, "signup.html")


class SearchView(View):
    def get(self, request):
        return render(request, "search.html")

    def post(self, request):
        print(request)
        query = request.POST.get("query")
        search_object = image_search(query)
        return render(request, "search.html", {'data': search_object})


def image_search(query):
    import requests
    url = "https://google-search72.p.rapidapi.com/imagesearch"
    querystring = {"query": query, "gl": "us", "lr": "en",
                   "num": "200", "start": "0", "sort": "relevance"}

    headers = {
        "X-RapidAPI-Key": "98a6b14f66msh105111533497136p15fa64jsn153d063fc751",
        "X-RapidAPI-Host": "google-search72.p.rapidapi.com"
    }

    response = requests.request(
        "GET", url, headers=headers, params=querystring)

    result = response.json()
    print(response)
    print(result)
    items = result["items"]

    return items
