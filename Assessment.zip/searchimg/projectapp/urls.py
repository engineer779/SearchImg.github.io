from django.contrib import admin
from django.urls import path, include

# from projectapp import views
from . import views


urlpatterns = [
    path("", views.index, name="projectapp"),
    path("signup", views.SignupViews.as_view(), name="signup"),
    path("login", views.LoginViews.as_view(), name="login"),
    path("search", views.SearchView.as_view()),
    path("", views.SignoutViews.as_view(), name='signout'),
    path("search_with_result", views.SearchView.as_view(),name="search_with_result")
]
